﻿cls

#$path_email = "C:\Users\DELL\Documents\ps1\get_file_TimeStamp\"
$path_email = "E:\archivy_6D2\"
$path_email = "E:\archivy_v7\"

echo $path_email

$all_rar = @(Get-ChildItem $path_email -Include '*.rar' -Name)

$delka_all_rar = $all_rar.length - 1

if ($delka_all_rar -clike -1) {
echo "zadne soubory *.rar v adresari $path_email"
echo "konec programu"
#sleep 5
#Exit
}

#echo $delka_all_rar
echo "ktery archiv rar rozpakovat ?"
echo "zadej cislo 0 az $delka_all_rar a zmackni <Enter>"
echo ""
for ($aa = 0; $aa -le ($delka_all_rar); $aa ++) {
$klic = [ string] $aa
$klic += ") "
$klic += $cesta
$klic +=  $all_rar[$aa]
echo $klic # v ciklu vypisuje soubory
}

# read
[int] $volba = Read-Host -Prompt '?'
$vybrany_rar = $all_rar[$volba]

# osetreni vstupu chyba zadani uzivatele
if ( $volba -gt  $delka_all_rar ) {
echo "chyba zadani" # vetsi
Remove-Variable -Name vybrany_rar
#sleep 3
Exit
} elseif ( $volba -lt 0 ) {
Remove-Variable -Name vybrany_rar
echo "chyba zadani" # mensi
#sleep 3
Exit
}
echo "byl vybran soubor $path_email$vybrany_rar"
#$hledej_datum = $vybrany_rar.Substring(0,16)
#echo $hledej_datum<<<<<<<<<<<<<<<<<<<<<


# --- odsud pridat do desifruj.sh verze 7

#[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object CreationTime
#[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object CreationTime,Name
#[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object LastWriteTime,CreationTime,Name # zde funguje
[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object LastWriteTime,Name
echo $file
# 31_12_2022-23_13 - vzor
#$datum_souboru = $file.Substring(15,2)+"_"+$file.Substring(18,2)+"_"+$file.Substring(21,4)+"-"+$file.Substring(26,2)+"_"+$file.Substring(29,2)
$hledej_datum = $file.Substring(19,2)+"_"+$file.Substring(16,2)+"_"+$file.Substring(22,4)+"-"+$file.Substring(27,2)+"_"+$file.Substring(30,2)
echo ">$hledej_datum< LastWriteTime ( odkazuje na heslo )"

# hleda string nazev
$n_Name = $file.IndexOf("Name=")
#echo $n_Name
$d_file=$file.Length -1
#echo $d_file
$rozdil_Name = $d_file - $n_Name
#echo $rozdil_Name
$nazev_souboru = $file.Substring($n_Name +5,$rozdil_Name -5)# pozn. -5 a +5 je delka retezce "Name=" najde prvni znak cili "N"
echo ">$nazev_souboru< nazev vybraneho souboru"
sleep 10
# pozn. kopirovani na jine misto v pocitaci nebo na flesku apod. se hodnota LastWriteTime nemeni !!! (i vypaleni na cd-cko)

# --- az sem do verze desifruj.sh verze 7

