﻿cls
# radek 184 az 207
<#---------------------------------------------------#>

# Name             : Windows PowerShell
# Version          : 5.1.19041.1682

# Edice	Windows 10 Pro
# Verze	21H2

<#---------------------------------------------------#>

$config_file_name = "config.cfg"
# config.cfg umisten v korenoven ardesari na cd-rw D:\ na flesce F:\ atd. ( vsechno mimo C:\ )

# v zahlavi spusteneho okna zobrazi informoce ( neco jako echo $0 v bash )
[string] $scriptName = pwd
#$scriptName += "\"
$scriptName += $MyInvocation.MyCommand.Name
$host.UI.RawUI.WindowTitle = $scriptName

# testuje kery pismeno je cd-mechanika a hleda soubor (bejva D:\ ale uz sem vydel ze mel nekdo i disk "O:\" apod.)
$nalezen_cfg = 0
for ($znak = 68; $znak -le 90; $znak++){ # jede od D - Z az 112
$file_config = [char] $znak
$file_config += ":\"
$jednotka = $file_config
#echo $jednotka
$file_config += $config_file_name
if (-not (Test-Path $file_config)){
#echo "nenalezeno"
}else{
#echo "nalezeno"
$nalezen_cfg = 1
break
}
}

#echo $jednotka
#echo $nalezen_cfg"< zde nalezen *.cfg"
echo "nalezen konfiguracni soubor $file_config"

if ($nalezen_cfg -like "0"){
Write-host -ForegroundColor yellow "nenalezen soubor $config_file_name"
Write-host -ForegroundColor yellow "Konec programu"
sleep 3
Exit
}

# cfg nalezen a jeho nacteni
$cfg = @()
$list_cfg = (Get-content -Path $file_config)
foreach($line_cfg in $list_cfg){
#echo $line_cfg
$cfg+=$line_cfg
}

# radek 1 config.cfg
$path_email = $cfg[0]

# stejna jednotka pro soubory rar jako zde ( misto C:\ ) # config.cfg radek 1 "#:\work" apod.
$stejna_jednotka_path_email = $path_email.Substring(0,1)
#echo $stejna_jednotka_path_email

if ($stejna_jednotka_path_email -clike "#"){
$path_email = $jednotka
$path_email += $cfg[0].Substring(0,0)
$path_email += $cfg[0].Substring(3, $cfg[0].Length -3)
#Write-Warning "zmena slozka souboru rar bude na tomto disku v $path_email/"
}

$path_email += "/"
#echo $path_email"<<<"
#exit

echo "pracovni adresar ze soubory *.rar nalezeni v $file_config je $path_email"

# $cfg[1] WinRar portable verze
$rar_1 = $cfg[1] # radek 2 config.cfg
$portable_rar_1 = $rar_1.Substring(0,1)
if ($portable_rar_1 -clike "#"){
$rar_1 = $jednotka
$rar_1 += $cfg[1].Substring(3, $cfg[1].Length -3)
# Write-Warning "portable verze WinRar config.cfg radek 2"
}
#echo $rar_1

# $cfg[2] WinRar portable verze
$rar_2 = $cfg[2] # radek 3 config.cfg
$portable_rar_2 = $rar_2.Substring(0,1)
if ($portable_rar_2 -clike "#"){
$rar_2 = $jednotka
$rar_2 += $cfg[2].Substring(3, $cfg[2].Length -3)
# Write-Warning "portable verze WinRar config.cfg radek 3"
}
#echo $rar_2

# $cfg[3] WinRar portable verze
$rar_3 = $cfg[3] # radek 4 config.cfg
$portable_rar_3 = $rar_3.Substring(0,1)
if ($portable_rar_3 -clike "#"){
$rar_3 = $jednotka
$rar_3 += $cfg[3].Substring(3, $cfg[3].Length -3)
# Write-Warning "portable verze WinRar config.cfg radek 4"
}
#echo $rar_3

# $cfg[4] WinRar portable verze
$rar_4 = $cfg[4] # radek 5 config.cfg
$portable_rar_4 = $rar_4.Substring(0,1)
if ($portable_rar_4 -clike "#"){
$rar_4 = $jednotka
$rar_4 += $cfg[4].Substring(3, $cfg[4].Length -3)
# Write-Warning "portable verze WinRar config.cfg radek 5"
}
#echo $rar_4

# radek 6 config.cfg
$adresar_hesla = $cfg[5]
#echo $adresar_hesla # < novy (adresar kde budou soubory hesel aby to nestrasilo v rootu)


# test instalace rar (4 moznosti)
if (Test-Path $rar_1){
$rar = $rar_1
}
elseif (Test-Path $rar_2){
$rar = $rar_2
}
elseif (Test-Path $rar_3){
$rar = $rar_3
}
elseif (Test-Path $rar_4){
$rar = $rar_4
}else{
Write-Warning "nainstalovat program WinRar"
sleep 5
Exit
}

echo "umisteni souboru WinRar nalezene v $file_config je $rar"

# hleda soubory *.rar
$all_rar = @(Get-ChildItem $path_email -Include '*.rar' -Name)

$delka_all_rar = $all_rar.length - 1

if ($delka_all_rar -clike -1) {
echo "zadne soubory *.rar v adresari $path_email"
echo "konec programu"
sleep 5
Exit
}

#echo $delka_all_rar
echo "ktery archiv rar rozpakovat ?"
echo "zadej cislo 0 az $delka_all_rar a zmackni <Enter>"
echo ""
for ($aa = 0; $aa -le ($delka_all_rar); $aa ++) {
$klic = [ string] $aa
$klic += ") "
$klic += $cesta
$klic +=  $all_rar[$aa]
echo $klic
}

# read
[int] $volba = Read-Host -Prompt '?'
$vybrany_rar = $all_rar[$volba]

# osetreni vstupu chyba zadani uzivatele
if ( $volba -gt  $delka_all_rar ){
echo "chyba zadani" # vetsi
Remove-Variable -Name vybrany_rar
sleep 3
Exit
} elseif ( $volba -lt 0 ) {
Remove-Variable -Name vybrany_rar
echo "chyba zadani" # mensi
sleep 3
Exit
}
echo "byl vybran soubor $path_email$vybrany_rar"
<#
vycteni casoveho razitka LastWriteTime z vybraneho souboru *.rar
kopirovani na jine misto v pocitaci na flesku, vypaleni na cd-cko atd. a nebo prejmenovanim souboru se hodnota LastWriteTime nemeni
kopirovanim se meni akorat CreationTime u LastWriteTime by se muselo vlez dovnit do souboru
v pruzkumnikovy ve windows LastWriteTime = sloupec Datum Zmeny
#>

#[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object LastWriteTime,Name
[string] $file = Get-ChildItem -Path "$path_email$vybrany_rar" -File | Select-Object LastWriteTime,LastAccessTime,CreationTime,Name

echo $file
# 31_12_2022-23_13 - vzor
$hledej_datum = $file.Substring(19,2)+"_"+$file.Substring(16,2)+"_"+$file.Substring(22,4)+"-"+$file.Substring(27,2)+"_"+$file.Substring(30,2)
#echo ">$hledej_datum< LastWriteTime ( nove odkazuje na heslo )"

# hleda string Name=
$n_Name = $file.IndexOf("Name=")
#echo $n_Name
$d_file=$file.Length -1
#echo $d_file
$rozdil_Name = $d_file - $n_Name
#echo $rozdil_Name
$nazev_souboru = $file.Substring($n_Name +5,$rozdil_Name -5)# pozn. -5 a +5 je delka retezce "Name=" najde prvni znak cili "N"
#echo ">$nazev_souboru< nazev souboru"

# subst rok vybrany soubor rar
$rok_nazev_rar = $file.Substring(22,4) # zde nutna zmena
#echo "$rok_nazev_rar"
#sleep 5

$file_kody = $jednotka + $adresar_hesla + "\" + "email_kody_" + $rok_nazev_rar + ".txt"

# test jestli existuje prislusni soubor hesel
if (-not (Test-Path $file_kody)){
Write-Warning "nenalezen soubor hesel $file_kody"
$hlaseni_generovat_soubor_hesel = $jednotka + "generovat_hesla\" + "generovat_hesla_" + $rok_nazev_rar + ".bat"
Write-Warning "spustit soubor $hlaseni_generovat_soubor_hesel"
Write-Warning "konec programu"
sleep 5
Exit
}

echo "otevren soubor hesel $file_kody"
#hledej_datum += "XXX" # testovaci aby nic nenasel                               <<<<<<<< testovaci radek
echo "$hledej_datum < datum hledany v souboru hesel"
sleep 3

# otevreni souboru hesel a hledani hesla
$reader = new-object System.IO.StreamReader($file_kody) # rychli nenarocny na ram
$count = 1
$lineNumber = 1
$pom_nalezeno = 0
while(($line = $reader.ReadLine()) -ne $null){
++$lineNumber 
if ($line.ToLower().Indexof($hledej_datum) -ge 0){
++$count
#Write-Host "$count $lineNumber $line <<"
$pom_nalezeno = 1
$nalezen_radek = $line
[string] $heslo = $lineNumber
$nalezen_radek_line = $count
[string] $heslo = $lineNumber
++$count
$heslo = $reader.ReadLine()
[int32] $radek_nalezeno_datum = $lineNumber
}
}
$reader.Close()
if ($pom_nalezeno -clike "0"){
echo "toto datum v souboru hesel nenalezeno"
sleep 5
Exit
}

$out_radek = [int32] $radek_nalezeno_datum - 1
echo "$nalezen_radek < nalezeno datum v suboru hesel"
echo "nalezeno datum v souboru hesel radek $out_radek"
#echo $heslo
sleep 5

# test a rozpakovani
& $rar "t" "-p$heslo" "$path_email$nazev_souboru" # test archivu
sleep 5

& $rar "x" "-p$heslo" "-y" "$path_email$nazev_souboru" "$path_email/"
Write-host -ForegroundColor cyan $heslo
echo "Hotovo"
sleep 5

